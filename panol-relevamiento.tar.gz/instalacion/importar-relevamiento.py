#!/usr/bin/env python3
"""
Importa un ZIP exportado por la app de relevamiento del celular.

    python3 importar-relevamiento.py relevamiento-cadete-2026-09-23.zip
    python3 importar-relevamiento.py *.zip --adjuntos C:/panol/adjuntos

Qué hace, por cada pieza del ZIP:
  1. crea el ítem con alta_rapida() — código provisorio, ficha marcada
     como incompleta, y el saldo inicial como ajuste con motivo;
  2. deja las tres versiones de la foto en la carpeta de adjuntos
     (original achicada, vista de 1200 px y miniatura de 200 px);
  3. registra la foto en item_adjunto y la marca como principal.

Por qué existe teniendo el endpoint del sistema: el relevamiento arranca
antes que el server. Esto permite cargar los ZIP en una base local,
revisar el catálogo y corregirlo con tiempo, y recién después llevarlo
al server. También sirve de respaldo si el endpoint falla.

Es idempotente por archivo: si se corre dos veces el mismo ZIP, la
segunda no duplica nada (se recuerda por el hash de cada foto y, sin
foto, por nombre + ubicación + momento).
"""
import argparse
import hashlib
import io
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    sys.exit("Falta Pillow.  pip install pillow")

PSQL = ["psql",
        "-h", os.environ.get("PGHOST", "127.0.0.1"),
        "-p", os.environ.get("PGPORT", "5433"),
        "-U", os.environ.get("PGUSER", "panol"),
        "-d", os.environ.get("PGDATABASE", "panol"), "-At", "-c"]

LADO_VISTA = 1200
LADO_MINI = 200


def sql(consulta):
    r = subprocess.run(PSQL + [consulta], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip().splitlines()[-1] if r.stderr else "psql falló")
    return r.stdout.strip()


def txt(v):
    """Literal SQL, o NULL. Sin esto, un nombre con apóstrofo rompe todo."""
    if v is None or v == "":
        return "NULL"
    return "'" + str(v).replace("'", "''") + "'"


def buscar_ubicacion(ruta):
    """
    Une el texto que escribió el relevador con un casillero de la base.

    En el pañol nadie escribe "Sector A - Rodamientos y transmisión /
    Estantería 2 / Casillero 3" igual dos veces, así que la comparación
    es sin acentos, sin mayúsculas y sin espacios de más.

    Si el texto completo no da, se va recortando desde el final:
    "Estantería 2 / Casillero 3", después "Casillero 3". Pero **solo se
    acepta si hay UNA sola ubicación que termine así**. Y no es un
    detalle: "Casillero 3" existe en cada estantería de cada sector, y
    la primera versión de esto agarraba el primero que encontraba —
    escribías "Estantería 2" y la pieza quedaba guardada en la 1, sin
    que nadie se enterara nunca. Una ubicación equivocada es peor que
    ninguna: manda a buscar la pieza al estante que no es.

    Cuando queda ambiguo devuelve None: la pieza entra igual, sin
    ubicación, y aparece en "Fichas por completar".
    """
    if not ruta:
        return None

    tramos = [t.strip() for t in str(ruta).split("/") if t.strip()]
    if not tramos:
        return None

    for desde in range(len(tramos)):
        cola = " / ".join(tramos[desde:])
        filas = sql("""
            SELECT u.id FROM ubicacion u
             WHERE lower(unaccent(regexp_replace(ubicacion_ruta(u.id), '\\s+', ' ', 'g')))
                   LIKE '%%' || lower(unaccent(regexp_replace(%s, '\\s+', ' ', 'g')))
             ORDER BY u.id""" % txt(cola))
        ids = [x for x in filas.splitlines() if x.strip()]
        if len(ids) == 1:
            return int(ids[0])
        if len(ids) > 1:
            # Ambiguo con este recorte, y recortar más solo puede empeorar.
            return None
    return None


def derivados(crudo):
    """Las dos versiones que sirve la pantalla, más el tamaño original."""
    im = Image.open(io.BytesIO(crudo))
    im = im.convert("RGB")
    salida = {}
    for clave, lado in (("vista", LADO_VISTA), ("mini", LADO_MINI)):
        copia = im.copy()
        copia.thumbnail((lado, lado), Image.LANCZOS)
        buf = io.BytesIO()
        copia.save(buf, "JPEG", quality=82, optimize=True)
        salida[clave] = buf.getvalue()
    salida["ancho"], salida["alto"] = im.size
    return salida


def importar(ruta_zip, carpeta_adjuntos, persona_id, seco=False):
    creados = omitidos = sin_ubicacion = errores = 0
    detalle_errores = []

    with zipfile.ZipFile(ruta_zip) as z:
        if "relevamiento.json" not in z.namelist():
            raise RuntimeError("El ZIP no tiene relevamiento.json — "
                               "¿es un export de la app de relevamiento?")
        datos = json.loads(z.read("relevamiento.json").decode("utf-8"))
        piezas = datos.get("piezas", [])
        print("%s — %d piezas, relevó %s"
              % (Path(ruta_zip).name, len(piezas), datos.get("relevadoPor") or "?"))

        for n, p in enumerate(piezas, start=1):
            nombre = (p.get("nombre") or "").strip()
            if len(nombre) < 3:
                errores += 1
                detalle_errores.append("pieza %d: sin nombre" % n)
                continue

            try:
                crudo = z.read(p["foto"]) if p.get("foto") else None
                hash_foto = hashlib.sha256(crudo).hexdigest() if crudo else None

                # Idempotencia: la misma foto ya importada, o la misma
                # pieza del mismo momento, no se vuelve a crear.
                if hash_foto:
                    ya = sql("SELECT item_id FROM item_adjunto WHERE hash_original = %s LIMIT 1"
                             % txt(hash_foto))
                else:
                    ya = sql("""
                        SELECT i.id FROM item i
                         WHERE lower(unaccent(i.nombre)) = lower(unaccent(%s))
                           AND i.creado_en >= %s::timestamptz - INTERVAL '1 second'
                           AND i.creado_en <= %s::timestamptz + INTERVAL '1 second'
                         LIMIT 1""" % (txt(nombre), txt(p.get("momento")), txt(p.get("momento"))))
                if ya:
                    omitidos += 1
                    continue

                ubic = buscar_ubicacion(p.get("ubicacion"))
                if p.get("ubicacion") and ubic is None:
                    sin_ubicacion += 1

                cantidad = p.get("cantidad") or 0
                if seco:
                    creados += 1
                    continue

                item_id = int(sql("""
                    SELECT (alta_rapida(%s, %s, %s, %s, %s, 'unidad', NULL, NULL)).id"""
                    % (txt(nombre),
                       ubic if ubic else "NULL",
                       cantidad if (cantidad and ubic) else "NULL",
                       persona_id if persona_id else "NULL",
                       txt(p.get("clase") or "repuesto"))))

                if crudo:
                    d = derivados(crudo)
                    carpeta = Path(carpeta_adjuntos) / str(item_id)
                    carpeta.mkdir(parents=True, exist_ok=True)
                    (carpeta / "original.jpg").write_bytes(crudo)
                    (carpeta / "vista.jpg").write_bytes(d["vista"])
                    (carpeta / "mini.jpg").write_bytes(d["mini"])
                    # Rutas relativas: el día que muevan la carpeta de
                    # adjuntos, o el server, no hay que reescribir la base.
                    rel = "%d" % item_id
                    sql("""
                        INSERT INTO item_adjunto
                          (item_id, tipo, ruta, ruta_vista, ruta_miniatura,
                           ancho, alto, bytes, tipo_mime, hash_original,
                           es_principal, subido_por)
                        VALUES (%d, 'foto', '%s/original.jpg', '%s/vista.jpg', '%s/mini.jpg',
                                %d, %d, %d, 'image/jpeg', %s, TRUE, %s)"""
                        % (item_id, rel, rel, rel,
                           d["ancho"], d["alto"], len(crudo), txt(hash_foto),
                           persona_id if persona_id else "NULL"))
                creados += 1

            except Exception as e:                      # noqa: BLE001
                errores += 1
                detalle_errores.append("pieza %d (%s): %s" % (n, nombre[:40], e))

    print("   creadas: %d   ya estaban: %d   con error: %d" % (creados, omitidos, errores))
    if sin_ubicacion:
        print("   OJO: %d piezas traían un casillero que no existe en la base. "
              "Entraron sin ubicación; revisá 'Fichas por completar'." % sin_ubicacion)
    for d in detalle_errores[:20]:
        print("     - " + d)
    return creados, omitidos, errores


def main():
    ap = argparse.ArgumentParser(description="Importa ZIPs de la app de relevamiento.")
    ap.add_argument("zips", nargs="+")
    ap.add_argument("--adjuntos", default=os.environ.get("PANOL_ADJUNTOS", "/var/panol/adjuntos"),
                    help="Carpeta donde el sistema guarda las fotos.")
    ap.add_argument("--persona", type=int, default=None,
                    help="ID de quién importa, para el libro mayor.")
    ap.add_argument("--seco", action="store_true",
                    help="No escribe nada: solo dice qué haría.")
    a = ap.parse_args()

    if a.seco:
        print("MODO SECO: no se escribe nada.\n")
    else:
        Path(a.adjuntos).mkdir(parents=True, exist_ok=True)

    tot = [0, 0, 0]
    for z in a.zips:
        try:
            c, o, e = importar(z, a.adjuntos, a.persona, a.seco)
            tot = [tot[0] + c, tot[1] + o, tot[2] + e]
        except Exception as ex:                          # noqa: BLE001
            print("%s: NO SE PUDO — %s" % (Path(z).name, ex))
            tot[2] += 1
        print()

    print("Total: %d creadas, %d ya estaban, %d con error" % tuple(tot))
    return 1 if tot[2] else 0


if __name__ == "__main__":
    sys.exit(main())
