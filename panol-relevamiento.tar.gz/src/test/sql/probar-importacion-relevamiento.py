#!/usr/bin/env python3
"""
Prueba del importador de ZIP del relevamiento.

Arma un ZIP con el mismo formato que exporta la app del celular —con
una ubicación que SÍ existe, otra ambigua y otra inventada—, lo importa
y revisa qué quedó en la base.

    python3 probar-importacion-relevamiento.py
"""
import io
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path
from datetime import datetime, timezone

from PIL import Image

RAIZ = Path(__file__).resolve().parents[3]
IMPORTADOR = RAIZ / "instalacion" / "importar-relevamiento.py"
TRABAJO = Path("/tmp/claude-0/prueba-relevamiento")
ADJUNTOS = TRABAJO / "adjuntos"

PSQL = ["psql",
        "-h", os.environ.get("PGHOST", "127.0.0.1"),
        "-p", os.environ.get("PGPORT", "5433"),
        "-U", os.environ.get("PGUSER", "panol"),
        "-d", os.environ.get("PGDATABASE", "panol"), "-At", "-c"]

R = []


def ok(nombre, cond, detalle=""):
    R.append((nombre, bool(cond), str(detalle)))


def sql(c):
    r = subprocess.run(PSQL + [c], capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else "ERROR: " + r.stderr.strip()[:120]


def foto_falsa(color):
    """Una imagen grande, para que se note que el importador la achica."""
    im = Image.new("RGB", (2400, 1800), color)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=90)
    return buf.getvalue()


TRABAJO.mkdir(parents=True, exist_ok=True)
for viejo in TRABAJO.glob("*.zip"):
    viejo.unlink()
if ADJUNTOS.exists():
    import shutil
    shutil.rmtree(ADJUNTOS)

casillero_real = sql("SELECT ubicacion_ruta(id) FROM ubicacion "
                     "WHERE tipo='casillero' ORDER BY 1 LIMIT 1")
momento = datetime.now(timezone.utc).isoformat()

piezas = [
    {"nombre": "Rodamiento de rodillos a rótula 22215", "cantidad": 4,
     "clase": "repuesto", "ubicacion": casillero_real,
     "relevadoPor": "Cadete 1", "momento": momento, "foto": "fotos/0001.jpg"},
    {"nombre": "Llave criquet 3/4 pulgada", "cantidad": 1,
     "clase": "herramienta", "ubicacion": "Casillero 3",     # ambigua a propósito
     "relevadoPor": "Cadete 1", "momento": momento, "foto": "fotos/0002.jpg"},
    {"nombre": "Aceite hidráulico en bidón", "cantidad": 0,
     "clase": "insumo", "ubicacion": "Galpón del fondo",     # no existe
     "relevadoPor": "Cadete 1", "momento": momento, "foto": None},
    {"nombre": "ab", "cantidad": 1,                          # nombre inválido
     "clase": "repuesto", "ubicacion": casillero_real,
     "relevadoPor": "Cadete 1", "momento": momento, "foto": None},
]

ruta_zip = TRABAJO / "relevamiento-prueba.zip"
with zipfile.ZipFile(ruta_zip, "w", zipfile.ZIP_STORED) as z:
    z.writestr("relevamiento.json", json.dumps(
        {"version": 1, "generadoEn": momento, "relevadoPor": "Cadete 1",
         "totalPiezas": len(piezas), "piezas": piezas}, ensure_ascii=False, indent=2))
    z.writestr("fotos/0001.jpg", foto_falsa((80, 90, 100)))
    z.writestr("fotos/0002.jpg", foto_falsa((140, 60, 40)))


def importar():
    r = subprocess.run(
        [sys.executable, str(IMPORTADOR), str(ruta_zip),
         "--adjuntos", str(ADJUNTOS), "--persona", "1"],
        capture_output=True, text=True, env={**os.environ})
    return r.stdout + r.stderr


salida1 = importar()

ok("importa las piezas válidas", "creadas: 3" in salida1, salida1.strip().splitlines()[-3:])
ok("rechaza la de nombre inválido", "con error: 1" in salida1)
ok("avisa de los casilleros que no pudo enganchar",
   "OJO" in salida1 and "2 piezas" in salida1,
   [l for l in salida1.splitlines() if "OJO" in l])

ok("las piezas quedaron como fichas provisorias",
   sql("SELECT count(*) FROM item WHERE provisorio AND sku LIKE 'PROV-%'") == "3")

ok("la ubicación que existía se enganchó",
   sql("""SELECT ubicacion_ruta(s.ubicacion_id) FROM stock s JOIN item i ON i.id=s.item_id
          WHERE i.nombre LIKE 'Rodamiento de rodillos%%'""") == casillero_real,
   casillero_real)

ok("la cantidad entró en esa ubicación",
   sql("""SELECT s.cantidad::int FROM stock s JOIN item i ON i.id=s.item_id
          WHERE i.nombre LIKE 'Rodamiento de rodillos%%'""") == "4")

# Lo más importante: una ubicación ambigua NO se adivina.
ok("la ubicación ambigua quedó SIN enganchar, no adivinada",
   sql("""SELECT count(*) FROM stock s JOIN item i ON i.id=s.item_id
          WHERE i.nombre LIKE 'Llave criquet%%'""") == "0")

ok("el saldo inicial entró como ajuste con motivo",
   sql("""SELECT m.motivo FROM movimiento m JOIN item i ON i.id=m.item_id
          WHERE i.nombre LIKE 'Rodamiento de rodillos%%' ORDER BY m.id LIMIT 1"""
       ).startswith("saldo inicial"))

ok("la foto quedó registrada y marcada como principal",
   sql("""SELECT count(*) FROM item_adjunto WHERE es_principal AND tipo='foto'""") == "2")

ok("el importador generó las tres versiones de cada foto",
   len(list(ADJUNTOS.rglob("*.jpg"))) == 6,
   "%d archivos" % len(list(ADJUNTOS.rglob("*.jpg"))))

vistas = sorted(ADJUNTOS.rglob("vista.jpg"))
if vistas:
    with Image.open(vistas[0]) as im:
        ok("la vista quedó achicada a 1200 px", max(im.size) <= 1200, "%dx%d" % im.size)
minis = sorted(ADJUNTOS.rglob("mini.jpg"))
if minis:
    with Image.open(minis[0]) as im:
        ok("la miniatura quedó en 200 px", max(im.size) <= 200, "%dx%d" % im.size)

# Se busca por lo que la pieza REALMENTE dice. "rulemanes" daría cero y
# estaría bien: ese término del taller es un sinónimo, y una ficha recién
# relevada no tiene ninguno todavía. Cargarlos es el paso siguiente, con
# la pieza ya en el sistema.
ok("las piezas importadas se encuentran buscando por su nombre",
   sql("SELECT count(*) FROM buscar_items('rodamiento rotula')") != "0",
   sql("SELECT count(*) FROM buscar_items('rodamiento rotula')"))
ok("y también por el código que trae el nombre",
   sql("SELECT count(*) FROM buscar_items('22215')") != "0",
   sql("SELECT count(*) FROM buscar_items('22215')"))
ok("un sinónimo del taller todavía NO las encuentra (hay que cargarlo)",
   sql("SELECT count(*) FROM buscar_items('rulemanes')") == "0")

ok("aparecen en la lista de fichas por completar",
   int(sql("SELECT count(*) FROM v_fichas_por_completar") or 0) >= 3)

# Reimportar el mismo archivo no puede duplicar nada.
antes = sql("SELECT count(*) FROM item")
salida2 = importar()
ok("reimportar el mismo ZIP no duplica",
   sql("SELECT count(*) FROM item") == antes and "ya estaban: 3" in salida2,
   [l for l in salida2.splitlines() if "creadas" in l])

ok("y tampoco duplica las fotos en disco",
   len(list(ADJUNTOS.rglob("*.jpg"))) == 6,
   "%d archivos" % len(list(ADJUNTOS.rglob("*.jpg"))))

bien = sum(1 for _, o, _ in R if o)
for nombre, o, detalle in R:
    print(("  OK   " if o else "  MAL  ") + nombre.ljust(54) + "  " + detalle)
print("\n%d de %d verificaciones" % (bien, len(R)))
sys.exit(0 if bien == len(R) else 1)
