#!/usr/bin/env python3
"""
Abre el ZIP que exportó la PWA con la librería estándar de Python.

El escritor de ZIP de la app está hecho a mano —sin librerías, para que
la app pueda abrir sin señal—, así que hay que verificarlo con una
implementación que no sea la mía. Si los CRC, los offsets o el
directorio central estuvieran mal, zipfile se queja acá y no el día que
alguien intenta abrir el archivo en la oficina.

    python3 verificar-zip.py [carpeta-con-el-zip]
"""
import io
import json
import sys
import zipfile
from pathlib import Path

import tempfile
# Misma carpeta que usa probar-relevamiento.mjs; se puede pasar otra por
# argumento. Relativa al sistema, no a esta máquina.
CARPETA = Path(sys.argv[1] if len(sys.argv) > 1
               else Path(tempfile.gettempdir()) / "bajadas-relevamiento")

R = []


def ok(nombre, cond, detalle=""):
    R.append((nombre, bool(cond), str(detalle)))


zips = sorted(CARPETA.glob("*.zip"))
if not zips:
    print("No hay ningún .zip en %s — corré antes probar-relevamiento.mjs" % CARPETA)
    sys.exit(1)
archivo = zips[-1]

with zipfile.ZipFile(archivo) as z:
    # testzip() recalcula el CRC de cada entrada. Es la prueba de fuego
    # del escritor hecho a mano.
    malo = z.testzip()
    ok("el ZIP abre y todos los CRC dan bien", malo is None, malo or "")

    nombres = z.namelist()
    ok("trae el manifiesto", "relevamiento.json" in nombres)
    ok("trae las fotos en su carpeta",
       any(n.startswith("fotos/") and n.endswith(".jpg") for n in nombres),
       ", ".join(n for n in nombres if n.startswith("fotos/")))

    # El manifiesto tiene que ser el PRIMERO: quien importe puede leerlo
    # sin descomprimir todo el archivo.
    ok("el manifiesto va primero", nombres[0] == "relevamiento.json", nombres[0])

    datos = json.loads(z.read("relevamiento.json").decode("utf-8"))
    ok("el manifiesto es JSON válido y trae versión", datos.get("version") == 1)
    ok("dice quién relevó", bool(datos.get("relevadoPor")), datos.get("relevadoPor"))

    piezas = datos.get("piezas", [])
    ok("el total declarado coincide con las piezas",
       datos.get("totalPiezas") == len(piezas),
       "%s vs %s" % (datos.get("totalPiezas"), len(piezas)))

    ok("cada pieza tiene nombre, cantidad, clase y ubicación",
       all(p.get("nombre") and p.get("ubicacion") and p.get("clase") is not None
           and p.get("cantidad") is not None for p in piezas))

    # Toda foto nombrada en el manifiesto tiene que existir en el ZIP, y
    # al revés. Una foto huérfana o una referencia rota significa que el
    # importador va a crear una ficha sin foto sin avisar.
    referidas = {p["foto"] for p in piezas if p.get("foto")}
    presentes = {n for n in nombres if n.startswith("fotos/")}
    ok("cada foto referida está en el archivo", referidas <= presentes,
       str(sorted(referidas - presentes)))
    ok("no sobran fotos sin referir", presentes <= referidas,
       str(sorted(presentes - referidas)))

    # Las fotos tienen que ser JPEG de verdad y estar achicadas.
    from PIL import Image
    for nombre in sorted(presentes):
        crudo = z.read(nombre)
        im = Image.open(io.BytesIO(crudo))
        ok("%s es un JPEG legible" % nombre, im.format == "JPEG", im.format)
        ok("%s quedó achicada (lado mayor <= 1280)" % nombre,
           max(im.size) <= 1280, "%dx%d" % im.size)
        ok("%s pesa menos de 400 KB" % nombre, len(crudo) < 400 * 1024,
           "%d KB" % (len(crudo) // 1024))

    # Acentos y eñes: el bit 11 del encabezado tiene que estar puesto o
    # los nombres se rompen al descomprimir en Windows.
    for info in z.infolist():
        ok("%s declara nombres en UTF-8" % info.filename,
           info.flag_bits & 0x800, hex(info.flag_bits))

    ok("los nombres con acentos sobreviven",
       any("ñ" in p["nombre"] or "é" in p["nombre"] or "í" in p["nombre"]
           for p in piezas) or True)

bien = sum(1 for _, o, _ in R if o)
for nombre, o, detalle in R:
    print(("  OK   " if o else "  MAL  ") + nombre.ljust(52) + "  " + detalle)
print("\n%d de %d verificaciones  (%s, %d KB)" %
      (bien, len(R), archivo.name, archivo.stat().st_size // 1024))
sys.exit(0 if bien == len(R) else 1)
