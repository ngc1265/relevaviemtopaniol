// =====================================================================
// Prueba de la pantalla de producción (src/main/resources/static).
//
// El backend Java no se puede compilar en este entorno (Maven Central
// bloqueado), así que se lo reemplaza por un doble que devuelve
// EXACTAMENTE las formas que devuelven los controladores reales. Las
// formas están copiadas de:
//
//   AccesoController.personas()  -> paraElegir()
//   AccesoController.entrar()    -> SeguridadService.Sesion
//   CatalogoController.buscar()  -> PaginaBusqueda {total, filas[]}
//   CatalogoController.detalle() -> {item, stock, sinonimos, foto, maquinas}
//   MovimientoController.registrar() -> {saldoNuevo, ...}
//   AlertaController.prestamos()
//   AltaRapidaController.rapida() / porCompletar()
//
// Esto NO prueba que el Java devuelva eso —para eso hay que compilar—,
// pero sí prueba que la pantalla funcione contra esas formas: que no
// tenga errores de sintaxis, que los flujos completen, que los permisos
// escondan lo que tienen que esconder y que no se rompa con campos
// vacíos.
//
//   node probar-pantalla.mjs
// =====================================================================
import { chromium } from 'playwright';
import { createServer } from 'http';
import { readFile } from 'fs/promises';
import { extname, join, dirname, resolve } from 'path';
import { existsSync } from 'fs';
import { fileURLToPath } from 'url';

// Relativo al guion, para que corra igual acá y en CI.
const AQUI = dirname(fileURLToPath(import.meta.url));
const RAIZ = resolve(AQUI, '../../..', 'src/main/resources/static');
const PUERTO = 8099;

const TIPOS = { '.html':'text/html', '.png':'image/png', '.js':'text/javascript',
                '.css':'text/css', '.ico':'image/x-icon' };

const servidor = createServer(async (req, res) => {
  try{
    const ruta = req.url === '/' ? '/index.html' : req.url.split('?')[0];
    const datos = await readFile(join(RAIZ, ruta));
    res.writeHead(200, { 'Content-Type': TIPOS[extname(ruta)] || 'application/octet-stream' });
    res.end(datos);
  }catch(e){ res.writeHead(404); res.end('no'); }
});
await new Promise(r => servidor.listen(PUERTO, r));

/* --------------------------- el doble ------------------------------ */

const PERMISOS_POR_ROL = {
  'Operario / Mecánico': ['buscar','egreso','prestamo','foto','sinonimo'],
  'Pañolero':            ['buscar','egreso','prestamo','ingreso','recibir','foto',
                          'sinonimo','transferencia','baja_rotura','ver_precios'],
  'Supervisor de mantenimiento': ['buscar','egreso','prestamo','ingreso','recibir','foto',
                          'sinonimo','transferencia','baja_rotura','ver_precios',
                          'abm_item','abm_maestros','abm_reglas','pedir','ajuste','ver_auditoria']
};

const estado = {
  siguienteId: 100,
  items: [
    { id:1, sku:'RD-6205-2RS', nombre:'Rodamiento rígido de bolas 6205-2RS',
      clase:'repuesto', unidadMedida:'unidad', criticidad:1, provisorio:false,
      cantidadTotal:6, ubicaciones:'Sector A / Estantería 1 / Casillero 1',
      maquinas:'Corrugadora 1 / Colero', miniatura:null },
    { id:2, sku:'TQ-1-2', nombre:'Torquímetro 1/2" 20-200 Nm',
      clase:'herramienta', unidadMedida:'unidad', criticidad:2, provisorio:false,
      cantidadTotal:1, ubicaciones:'Sector H / Estantería 1 / Casillero 1',
      maquinas:'', miniatura:null },
    { id:3, sku:'PROV-00001', nombre:'reten grande del doble faz',
      clase:'repuesto', unidadMedida:'unidad', criticidad:3, provisorio:true,
      cantidadTotal:0, ubicaciones:'', maquinas:'', miniatura:null }
  ],
  movimientos: []
};

const llamadas = [];

async function responder(ruta, metodo, cuerpo, cab){
  llamadas.push(metodo + ' ' + ruta);
  const persona = cab['x-persona-id'] ? Number(cab['x-persona-id']) : null;

  if (ruta === '/api/acceso/personas')
    return [{ id:3, nombre:'Mecánico 1', rol:'Operario / Mecánico' },
            { id:2, nombre:'Pañolero',   rol:'Pañolero' },
            { id:5, nombre:'Supervisor', rol:'Supervisor de mantenimiento' }];

  if (ruta === '/api/acceso/pin'){
    const b = JSON.parse(cuerpo);
    if (b.clave !== '1234') return { __estado:401, detail:'PIN incorrecto.' };
    const nombres = { 3:['Mecánico 1','Operario / Mecánico'],
                      2:['Pañolero','Pañolero'],
                      5:['Supervisor','Supervisor de mantenimiento'] };
    const [nombre, rol] = nombres[b.personaId];
    return { personaId:b.personaId, nombre, rol,
             permisos:PERMISOS_POR_ROL[rol], debeCambiarPin:false };
  }

  if (ruta === '/api/maquinas')
    return [{ id:1, nombre:'Corrugadora 1', parent:null },
            { id:2, nombre:'Colero', parent:{ id:1 } }];
  if (ruta === '/api/ubicaciones')
    return [{ id:10, nombre:'Sector A', tipo:'sector', parent:null },
            { id:11, nombre:'Estantería 1', tipo:'estanteria', parent:{ id:10 } },
            { id:12, nombre:'Casillero 1', tipo:'casillero', parent:{ id:11 } },
            { id:13, nombre:'Casillero 2', tipo:'casillero', parent:{ id:11 } }];
  if (ruta === '/api/personas')
    return [{ id:3, nombre:'Mecánico 1' }, { id:2, nombre:'Pañolero' },
            { id:5, nombre:'Supervisor' }];

  // Con la búsqueda vacía la pantalla pide "/api/catalogo?" y el `search`
  // de la URL sale vacío, así que la ruta llega sin el "?". Hay que
  // contemplar las dos formas o el primer pintado se ve como si el
  // servidor estuviera caído.
  if (ruta === '/api/catalogo' || ruta.startsWith('/api/catalogo?')){
    const q = new URLSearchParams((ruta.split('?')[1] || ''));
    const texto = (q.get('texto') || '').toLowerCase();
    const filas = estado.items.filter(i =>
      !texto || i.nombre.toLowerCase().includes(texto) || i.sku.toLowerCase().includes(texto));
    return { total: filas.length, filas };
  }

  if (/^\/api\/catalogo\/\d+$/.test(ruta)){
    const id = Number(ruta.split('/').pop());
    const i = estado.items.find(x => x.id === id);
    if (!i) return { __estado:404, detail:'No existe' };
    return { item:i,
             stock: i.cantidadTotal > 0
               ? [{ ubicacion:{ id:12 }, cantidad:i.cantidadTotal }] : [],
             sinonimos: [{ termino:'ruleman' }],
             foto: null,
             maquinas: i.maquinas ? [{ id:2, nombre:'Colero' }] : [],
             puedeVerPrecios: false };
  }

  if (/^\/api\/catalogo\/\d+\/sinonimos$/.test(ruta))
    return { id:1, termino: JSON.parse(cuerpo).termino };

  if (ruta === '/api/movimientos' && metodo === 'POST'){
    const b = JSON.parse(cuerpo);
    if (!b.registradoPorId) return { __estado:400, detail:'Falta quién carga el movimiento.' };
    const i = estado.items.find(x => x.id === b.itemId);
    const signo = (b.tipo === 'INGRESO_COMPRA' || b.tipo === 'DEVOLUCION') ? 1 : -1;
    if (signo < 0 && i.cantidadTotal < b.cantidad)
      return { __estado:400, detail:`Stock insuficiente: se pidieron ${b.cantidad} y hay ${i.cantidadTotal}.` };
    i.cantidadTotal += signo * b.cantidad;
    estado.movimientos.push(b);
    return { saldoNuevo: i.cantidadTotal };
  }

  if (ruta === '/api/alta' && metodo === 'POST'){
    const b = JSON.parse(cuerpo);
    if (!b.nombre || b.nombre.trim().length < 3)
      return { __estado:400, detail:'Poné un nombre de por lo menos 3 letras.' };
    const item = { id: ++estado.siguienteId,
      sku:'PROV-' + String(estado.siguienteId).padStart(5,'0'),
      nombre:b.nombre, clase:b.clase || 'repuesto', unidadMedida:'unidad',
      criticidad:3, provisorio:true, cantidadTotal:Number(b.cantidad || 0),
      ubicaciones:b.ubicacionId ? 'Sector A / Estantería 1 / Casillero 1' : '',
      maquinas:'', miniatura:null };
    estado.items.push(item);
    return item;
  }

  if (ruta.startsWith('/api/alta/por-completar'))
    return estado.items.filter(i => i.provisorio).map(i => ({
      id:i.id, sku:i.sku, nombre:i.nombre, faltaCodigo:true, faltaCategoria:true,
      faltaMaquina:true, faltaFoto:true, faltaPunto:true, faltaProveedor:true,
      hay:i.cantidadTotal, movimientos90d:0 }));

  if (ruta === '/api/alertas/prestamos')
    return [{ itemId:2, sku:'TQ-1-2', item:'Torquímetro 1/2" 20-200 Nm',
              persona:'Mecánico 1', desde:'2026-09-10T08:00:00Z', diasAtraso:5 }];

  if (/^\/api\/items\/\d+\/fotos$/.test(ruta) && metodo === 'POST')
    return { id:1, tipo:'foto', rutaVista:'/img/icono.png' };

  return { __estado:404, detail:'ruta no simulada: ' + ruta };
}

/* --------------------------- la corrida ----------------------------- */

const R = [];
const ok = (nombre, cond, detalle='') => R.push({ nombre, ok: !!cond, detalle });

// En el contenedor de desarrollo Chromium está en una ruta fija; en CI
// lo instala Playwright y hay que dejarlo elegir.
const CHROMIUM = '/opt/pw-browsers/chromium';
const navegador = await chromium.launch(Object.assign(
  { args:['--disable-background-networking','--no-first-run'] },
  existsSync(CHROMIUM) ? { executablePath: CHROMIUM } : {}
));
const contexto = await navegador.newContext({ viewport:{ width:1280, height:900 } });
const pag = await contexto.newPage();

const erroresJs = [];
pag.on('pageerror', e => erroresJs.push(e.message));
// El navegador loguea en consola CUALQUIER respuesta HTTP que no sea
// 2xx, y este guion provoca un 401 (PIN equivocado) y un 400 (stock
// insuficiente) a propósito para verificar que la pantalla los muestre
// bien. Esos no son errores de la pantalla; los de JavaScript sí.
pag.on('console', m => {
  if (m.type() === 'error' && !/Failed to load resource/.test(m.text())){
    erroresJs.push('console: ' + m.text());
  }
});

await pag.route('**/api/**', async ruta => {
  const req = ruta.request();
  const url = new URL(req.url());
  const r = await responder(url.pathname + url.search, req.method(),
                            req.postData(), req.headers());
  const estadoHttp = r && r.__estado ? r.__estado : 200;
  if (r) delete r.__estado;
  await ruta.fulfill({ status: estadoHttp, contentType:'application/json',
                       body: JSON.stringify(r) });
});

pag.setDefaultTimeout(6000);
await pag.goto(`http://127.0.0.1:${PUERTO}/`);
await pag.waitForTimeout(600);

// Si algo revienta a mitad de camino, igual queremos ver hasta dónde
// llegó y qué había en pantalla: un stack trace solo no alcanza para
// saber qué se rompió.
try{

// ---- 1. acceso -------------------------------------------------------
ok('la pantalla de acceso aparece sola', await pag.locator('#acceso').isVisible());
ok('lista las personas', (await pag.locator('.persona-bot').count()) === 3);

await pag.locator('.persona-bot:has-text("Mecánico 1")').click();
await pag.waitForTimeout(300);
ok('pide el PIN después del nombre', await pag.locator('#accesoPin').isVisible());
ok('la lista de nombres se esconde', !(await pag.locator('#accesoPersonas').isVisible()));

for (const d of '9999') await pag.click(`[data-tecla="${d}"]`);
await pag.waitForTimeout(500);
ok('rechaza el PIN equivocado', await pag.locator('#accesoError').isVisible(),
   await pag.locator('#accesoError').textContent());

for (const d of '1234') await pag.click(`[data-tecla="${d}"]`);
await pag.waitForTimeout(700);
ok('entra con el PIN correcto', !(await pag.locator('#acceso').isVisible()));
ok('muestra quién está operando',
   (await pag.locator('#chipUsuario').textContent()).includes('Mecánico 1'));

// ---- 2. permisos por rol --------------------------------------------
await pag.waitForTimeout(400);
const htmlResultados = await pag.locator('#resultados').innerHTML();
ok('el mecánico ve "Sacar" en un repuesto', htmlResultados.includes('>Sacar<'));
ok('el mecánico ve "Prestar" en una herramienta', htmlResultados.includes('>Prestar<'));
ok('el mecánico NO ve "Ingresar" (no tiene el permiso)',
   !htmlResultados.includes('>Ingresar<'));

// ---- 3. egreso -------------------------------------------------------
await pag.locator('[data-mover="1"][data-tipo="EGRESO_CONSUMO"]').click();
await pag.waitForTimeout(400);
ok('el diálogo de egreso pide origen', await pag.locator('#eUbicacion').count() === 1);
ok('el egreso pide máquina', await pag.locator('#eMaquina').count() === 1);
ok('el egreso NO pide destino', await pag.locator('#eDestino').count() === 0);

await pag.fill('#eCantidad', '2');
await pag.selectOption('#eMaquina', { index: 1 });
await pag.click('#btnConfirmar');
await pag.waitForTimeout(600);
ok('el egreso se registra', estado.items[0].cantidadTotal === 4,
   'quedan ' + estado.items[0].cantidadTotal);
const ultimo = estado.movimientos[estado.movimientos.length - 1];
ok('el movimiento lleva quién lo cargó', ultimo && ultimo.registradoPorId === 3,
   String(ultimo && ultimo.registradoPorId));

// ---- 4. el error del servidor se ve ----------------------------------
await pag.locator('[data-mover="1"][data-tipo="EGRESO_CONSUMO"]').click();
await pag.waitForTimeout(400);
await pag.fill('#eCantidad', '999');
await pag.click('#btnConfirmar');
await pag.waitForTimeout(600);
const textoError = await pag.locator('#dlgError').textContent();
ok('muestra el error real del servidor, no uno genérico',
   textoError.includes('Stock insuficiente'), textoError.trim());
await pag.keyboard.press('Escape');
await pag.waitForTimeout(300);

// ---- 5. préstamo -----------------------------------------------------
await pag.locator('[data-mover="2"][data-tipo="PRESTAMO"]').click();
await pag.waitForTimeout(400);
ok('el préstamo pide fecha de devolución', await pag.locator('#eFecha').count() === 1);
await pag.click('#btnConfirmar');
await pag.waitForTimeout(600);
ok('el préstamo se registra', estado.items[1].cantidadTotal === 0);

// ---- 6. prestadas y devolución --------------------------------------
await pag.click('#tabPrestamos');
await pag.waitForTimeout(600);
const htmlPrestamos = await pag.locator('#panelSecundario').innerHTML();
ok('lista las herramientas afuera', htmlPrestamos.includes('Torquímetro'));
ok('muestra los días de atraso', htmlPrestamos.includes('atraso'));
await pag.locator('[data-tipo="DEVOLUCION"]').first().click();
await pag.waitForTimeout(400);
ok('la devolución pide destino', await pag.locator('#eDestino').count() === 1);
ok('la devolución NO pide origen', await pag.locator('#eUbicacion').count() === 0);
await pag.click('#btnConfirmar');
await pag.waitForTimeout(600);
ok('la devolución suma al stock', estado.items[1].cantidadTotal === 1);

// ---- 7. búsqueda vacía y alta rápida --------------------------------
await pag.click('#tabBuscar');
await pag.waitForTimeout(400);
await pag.fill('#q', 'bocina de bronce');
await pag.waitForTimeout(700);
ok('el mecánico NO ve el botón de cargar (sin abm_item)',
   (await pag.locator('[data-alta]').count()) === 0);

// Cambiar a supervisor, que sí puede.
await pag.click('#chipUsuario');
await pag.waitForTimeout(400);
await pag.locator('.persona-bot:has-text("Supervisor")').click();
for (const d of '1234') await pag.click(`[data-tecla="${d}"]`);
await pag.waitForTimeout(700);
await pag.fill('#q', 'bocina de bronce');
await pag.waitForTimeout(700);
ok('el supervisor sí ve el botón de cargar',
   (await pag.locator('[data-alta]').count()) === 1);
ok('el botón propone lo que se buscó',
   (await pag.locator('[data-alta]').textContent()).includes('bocina de bronce'));

await pag.locator('[data-alta]').click();
await pag.waitForTimeout(400);
ok('el alta llega con el nombre ya puesto',
   (await pag.inputValue('#aNombre')) === 'bocina de bronce');
await pag.selectOption('#aUbicacion', { index: 1 });
await pag.fill('#aCantidad', '3');
await pag.click('#btnAltaConfirmar');
await pag.waitForTimeout(800);
const creado = estado.items[estado.items.length - 1];
ok('el alta rápida crea el ítem', creado && creado.nombre === 'bocina de bronce', creado?.sku);
ok('queda con código provisorio', creado && creado.sku.startsWith('PROV-'), creado?.sku);
ok('el alta con solo el nombre no exige SKU',
   !llamadas.some(l => l.includes('/api/catalogo') && l.startsWith('POST')));

// ---- 8. fichas por completar ----------------------------------------
await pag.click('#tabCompletar');
await pag.waitForTimeout(700);
const htmlCompletar = await pag.locator('#panelSecundario').innerHTML();
ok('lista las fichas incompletas', htmlCompletar.includes('bocina de bronce'));
ok('dice qué le falta a cada una', htmlCompletar.includes('falta foto'));

// ---- 9. ficha --------------------------------------------------------
await pag.locator('#panelSecundario [data-ficha]').first().click();
await pag.waitForTimeout(600);
ok('la ficha abre', await pag.locator('#dlgFicha').isVisible());
const htmlFicha = await pag.locator('#fichaCuerpo').innerHTML();
ok('la ficha avisa cuando no hay foto', htmlFicha.includes('Sin foto de referencia'));
ok('la ficha ofrece cargar un término nuevo', htmlFicha.includes('nuevoSin'));
ok('la ficha no se rompe sin stock ni máquinas', !htmlFicha.includes('undefined'),
   htmlFicha.includes('undefined') ? 'aparece "undefined"' : '');
await pag.keyboard.press('Escape');

// ---- 10. sin errores de JavaScript ----------------------------------
ok('la pantalla no tiró ningún error de JavaScript', erroresJs.length === 0,
   erroresJs.slice(0, 3).join(' | '));

}catch(err){
  R.push({ nombre:'la corrida terminó sin colgarse', ok:false, detalle:err.message.split('\n')[0] });
  try{
    console.log('\n--- #resultados al momento de la falla ---');
    console.log((await pag.locator('#resultados').innerHTML()).slice(0, 900));
    console.log('--- #panelSecundario ---');
    console.log((await pag.locator('#panelSecundario').innerHTML()).slice(0, 400));
  }catch(e2){ /* la página ya no está */ }
}

/* --------------------------- resultado ------------------------------ */
const bien = R.filter(r => r.ok).length;
for (const r of R){
  console.log((r.ok ? '  OK   ' : '  MAL  ') + r.nombre.padEnd(56) + '  ' + r.detalle);
}
console.log(`\n${bien} de ${R.length} verificaciones`);

await contexto.close();
await navegador.close();
servidor.close();
process.exit(bien === R.length ? 0 : 1);
