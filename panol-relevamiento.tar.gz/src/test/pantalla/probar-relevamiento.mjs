// =====================================================================
// Prueba de la PWA de relevamiento.
//
// Corre en un navegador con viewport de celular, carga fichas de verdad
// con fotos de verdad, y descarga el ZIP. El ZIP después lo abre
// verificar-zip.py con la librería estándar de Python: si el formato
// que escribí a mano estuviera mal, ahí se cae.
//
//   node probar-relevamiento.mjs
// =====================================================================
import { chromium } from 'playwright';
import { createServer } from 'http';
import { readFile, mkdir, rm } from 'fs/promises';
import { existsSync } from 'fs';
import { extname, join, dirname, resolve } from 'path';
import { fileURLToPath } from 'url';
import { tmpdir } from 'os';

// Rutas relativas al guion: el mismo archivo corre acá y en CI, donde el
// repositorio está en otra carpeta.
const AQUI = dirname(fileURLToPath(import.meta.url));
const REPO = resolve(AQUI, '../../..');
const RAIZ = join(REPO, 'relevamiento');
const FOTO = join(REPO, 'videos/fuentes/material/foto-ejemplo-rodamiento.jpg');
const BAJADAS = join(tmpdir(), 'bajadas-relevamiento');
const PUERTO = 8098;

const TIPOS = { '.html':'text/html', '.png':'image/png', '.js':'text/javascript',
                '.webmanifest':'application/manifest+json' };

const servidor = createServer(async (req, res) => {
  try{
    const ruta = req.url === '/' ? '/index.html' : req.url.split('?')[0];
    const datos = await readFile(join(RAIZ, ruta));
    res.writeHead(200, { 'Content-Type': TIPOS[extname(ruta)] || 'application/octet-stream' });
    res.end(datos);
  }catch(e){ res.writeHead(404); res.end('no'); }
});
await new Promise(r => servidor.listen(PUERTO, r));

await rm(BAJADAS, { recursive:true, force:true });
await mkdir(BAJADAS, { recursive:true });

const R = [];
const ok = (nombre, cond, detalle='') => R.push({ nombre, ok: !!cond, detalle });

const CHROMIUM = '/opt/pw-browsers/chromium';
const navegador = await chromium.launch(Object.assign(
  { args:['--disable-background-networking','--no-first-run'] },
  existsSync(CHROMIUM) ? { executablePath: CHROMIUM } : {}
));
// Un celular de verdad: pantalla chica y táctil. Si los botones no
// entran o se pisan, acá se ve.
const contexto = await navegador.newContext({
  viewport:{ width:390, height:844 },
  deviceScaleFactor:3, isMobile:true, hasTouch:true,
  acceptDownloads:true,
  userAgent:'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 ' +
            '(KHTML, like Gecko) Chrome/120 Mobile Safari/537.36'
});
const pag = await contexto.newPage();

const erroresJs = [];
pag.on('pageerror', e => erroresJs.push(e.message));
pag.on('console', m => {
  if (m.type() === 'error' && !/Failed to load resource/.test(m.text())){
    erroresJs.push('console: ' + m.text());
  }
});

pag.setDefaultTimeout(8000);

try{

await pag.goto(`http://127.0.0.1:${PUERTO}/`);
await pag.waitForTimeout(700);

// ---- 1. primer arranque --------------------------------------------
ok('la primera vez pide quién releva', await pag.locator('#p-quien').isVisible());
ok('no muestra la barra de abajo antes de empezar',
   !(await pag.locator('nav.pie').isVisible()));

await pag.fill('#iQuien', 'Cadete 1');
await pag.click('#btnQuien');
await pag.waitForTimeout(400);
ok('después de poner el nombre pasa a cargar', await pag.locator('#p-cargar').isVisible());
ok('el nombre queda a la vista',
   (await pag.locator('#quien').textContent()).includes('Cadete 1'));

// ---- 2. no deja cargar sin lugar -----------------------------------
await pag.fill('#iNombre', 'reten grande del doble faz');
await pag.click('#btnGuardar');
await pag.waitForTimeout(300);
ok('no deja guardar sin decir dónde está',
   await pag.locator('#errCargar').isVisible(),
   (await pag.locator('#errCargar').textContent()).trim());

// ---- 3. lugar -------------------------------------------------------
await pag.click('#btnLugar');
await pag.waitForTimeout(300);
await pag.fill('#iLugar', 'Sector A / Estantería 2 / Casillero 3');
await pag.click('#btnLugarOk');
await pag.waitForTimeout(300);
ok('el lugar queda fijo arriba',
   (await pag.locator('#lugarActual').textContent()).includes('Casillero 3'));

// ---- 4. carga con foto ---------------------------------------------
await pag.setInputFiles('#iFoto', FOTO);
await pag.waitForTimeout(1800);
const peso = await pag.locator('#pesoFoto').textContent();
ok('la foto se achica al sacarla', /KB → \d+ KB/.test(peso), peso.trim());

const [origen, achicada] = peso.match(/(\d+) KB → (\d+) KB/).slice(1).map(Number);
ok('la foto achicada pesa mucho menos que la original',
   achicada < origen / 5, `${origen} KB → ${achicada} KB`);

await pag.fill('#iCantidad', '6');
await pag.click('#btnGuardar');
await pag.waitForTimeout(700);
ok('guarda la primera ficha',
   (await pag.locator('#cuentaLista').textContent()) === '1');

// ---- 5. queda listo para la próxima --------------------------------
ok('limpia el nombre para la próxima', (await pag.inputValue('#iNombre')) === '');
ok('limpia la foto para la próxima', await pag.locator('#vistaFoto').isHidden());
ok('NO limpia el lugar (se sigue en el mismo estante)',
   (await pag.locator('#lugarActual').textContent()).includes('Casillero 3'));

// ---- 6. sin foto también entra --------------------------------------
await pag.fill('#iNombre', 'correa trapezoidal B98');
await pag.fill('#iCantidad', '2');
await pag.click('#btnGuardar');
await pag.waitForTimeout(600);
ok('se puede cargar sin foto',
   (await pag.locator('#cuentaLista').textContent()) === '2');

// ---- 7. herramienta -------------------------------------------------
await pag.click('[data-clase="herramienta"]');
await pag.fill('#iNombre', 'torquimetro 1/2');
await pag.fill('#iCantidad', '1');
await pag.click('#btnGuardar');
await pag.waitForTimeout(600);
ok('se puede marcar como herramienta',
   (await pag.locator('#cuentaLista').textContent()) === '3');

// ---- 8. lista -------------------------------------------------------
await pag.click('#tabLista');
await pag.waitForTimeout(600);
const htmlLista = await pag.locator('#listaFichas').innerHTML();
ok('la lista muestra lo cargado', htmlLista.includes('reten grande'));
ok('la lista marca lo que no tiene foto', htmlLista.includes('sin<br>foto'));
await pag.fill('#iBuscarLista', 'correa');
await pag.waitForTimeout(400);
ok('se puede buscar en lo cargado',
   (await pag.locator('.ficha').count()) === 1);
await pag.fill('#iBuscarLista', '');
await pag.waitForTimeout(300);

// ---- 9. sobrevive a cerrar la app ----------------------------------
await pag.reload();
await pag.waitForTimeout(900);
ok('al reabrir NO vuelve a pedir el nombre', await pag.locator('#p-cargar').isVisible());
ok('lo cargado sigue estando después de cerrar',
   (await pag.locator('#cuentaLista').textContent()) === '3');
ok('el lugar también se recuerda',
   (await pag.locator('#lugarActual').textContent()).includes('Casillero 3'));

// ---- 10. exportar ---------------------------------------------------
await pag.click('#tabExportar');
await pag.waitForTimeout(500);
const detalle = await pag.locator('#expDetalle').textContent();
ok('el resumen dice cuántas tienen foto', /1 con foto/.test(detalle), detalle.trim());

const bajada = pag.waitForEvent('download', { timeout: 20000 });
await pag.click('#btnExportar');
const archivo = await bajada;
const destino = join(BAJADAS, archivo.suggestedFilename());
await archivo.saveAs(destino);
ok('se baja un archivo .zip', destino.endsWith('.zip'), archivo.suggestedFilename());
ok('el nombre del archivo lleva quién relevó',
   archivo.suggestedFilename().includes('cadete'), archivo.suggestedFilename());

// ---- 11. vaciar pide confirmar dos veces ----------------------------
let confirmaciones = 0;
pag.on('dialog', d => { confirmaciones++; d.dismiss(); });
await pag.click('#btnVaciar');
await pag.waitForTimeout(500);
ok('vaciar pide confirmación antes de borrar', confirmaciones >= 1,
   confirmaciones + ' confirmación(es)');
ok('al cancelar no borra nada',
   (await pag.locator('#cuentaLista').textContent()) === '3');

// ---- 12. sin errores de JavaScript ----------------------------------
ok('no tiró ningún error de JavaScript', erroresJs.length === 0,
   erroresJs.slice(0, 2).join(' | '));

}catch(err){
  R.push({ nombre:'la corrida terminó sin colgarse', ok:false,
           detalle: err.message.split('\n')[0] });
}

const bien = R.filter(r => r.ok).length;
for (const r of R) console.log((r.ok ? '  OK   ' : '  MAL  ') + r.nombre.padEnd(54) + '  ' + r.detalle);
console.log(`\n${bien} de ${R.length} verificaciones`);
console.log('ZIP en: ' + BAJADAS);

await contexto.close();
await navegador.close();
servidor.close();
process.exit(bien === R.length ? 0 : 1);
